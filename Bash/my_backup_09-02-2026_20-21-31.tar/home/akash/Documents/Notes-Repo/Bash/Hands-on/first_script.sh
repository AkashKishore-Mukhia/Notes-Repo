#!/bin/bash

# Author: Akash Mukhia

# Description
# It's a basic 'Hello world printing script'

#Usage
# print 'Hello World to the console'

echo "Hello World"

exit 0